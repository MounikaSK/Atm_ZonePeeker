import Header from "./Header/Header";
import LandingContent from "./LandingContent/LandingContent";
import SearchCont from "./Header/SearchCont";

// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import "bootstrap/dist/js/bootstrap.bundle.min";


export{Header, LandingContent, SearchCont};