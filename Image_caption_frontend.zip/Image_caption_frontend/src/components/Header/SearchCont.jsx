import React from 'react';
import "./SearchCont.css";
import "./Header.jsx";



const SearchCont = ({captions}) => {
 console.log("Cap from search: ",captions)
  return (
    <section id="captionpage" className='captiongen'>
      <div className='MainPage'>
  
      {captions && (
          <div className="caption-output">
            <p>Generated Caption:</p>
            <p>{captions}</p>
          </div>
        )}
      <p>PLzzzz vandhruuuuuuu</p>
      </div>


    </section>
  )
}

export default SearchCont