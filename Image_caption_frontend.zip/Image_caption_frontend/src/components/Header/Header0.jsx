// import React from 'react';
// import "./Header.css";
// import { useState, useEffect } from "react";

// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
// import { Button, Container, Row, Col, Navbar, Nav, Form, FormControl } from 'react-bootstrap';


// const Header = () => {

//   console.log("First")
//   const [searchInput, setSearchInput] = useState('');
//   const [output, setOutput] = useState('');

//   const executePythonScript = () => {
//     fetch("http://localhost:3001/print-search-query", { // Update the URL to match your server
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//     },
//     body: JSON.stringify({ searchText: searchInput }),
//   })
//     .then((response) => response.text())
//     .then((data) => {
//       console.log(data); // Response from the server
//     })
//     .catch((error) => {
//       console.error("Error sending search request:", error);
//     });
//   };
//   return (
//     <header>
//       <div className='MainPage'>
//         <nav className='TopLine'>
//           <img src="src/assets/logo_image.png" alt="Image 1" className="logo-img" />
//            <a href="#" className='logo'>PicLingo</a>
      
      
//         <ul>
//           <li>
//             <a href="#">About Us</a>
//           </li>

//           <li>
//             <a href="#">How it Works</a>
//           </li>

//           <li>
//             <a href="#">Sign Out</a>
//           </li>
//         </ul>
//         <button className="cont-button">Contact Us</button>
//         </nav>

//         <div className='TagAlign'>
//         <h1 className="MainTag1">
//         <span className="FirstHeader1">Frames</span>
//         <span className="SecondHeader1">  Unveiled,</span>
//         </h1>
//         <br></br>
        
//         <h1 className="MainTag2">
//         <span className="FirstHeader2">Words</span>
//         <span className="SecondHeader2"> Tailored</span>
//         </h1>
        
//         <h3 className='SubTag'>Your Pictures, Your Words, Any Language.</h3>
//         <input
//           className="input-box" // Adjusted width and added padding-left
//           type="text"
//           placeholder="Paste or Type the URL of the image"
//           value={searchInput}
//           onChange={(e) => setSearchInput(e.target.value)}
//         />
//         <br></br>
//         <br></br>
//         <br></br>
//         <button className="gen-button" onClick={executePythonScript}>Start Generating Captions!</button>
      
//         </div>

//         <div className="ImagesContainer">
//         <div className="background">
//         <img src="src/assets/LI_1.avif" alt="Image 1" className="image image1" />
//         </div>
//       </div>

    
//       </div>


//     </header>
//   );
// };

// export default Header

import React from 'react';
import "./Header.css";
import { useState, useEffect } from "react";

import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import { Button, Container, Row, Col, Navbar, Nav, Form, FormControl } from 'react-bootstrap';


const Header = () => {

  console.log("First")
  const [searchInput, setSearchInput] = useState('');
  const [output, setOutput] = useState('');

  const executePythonScript = () => {
    fetch("http://localhost:3001/print-search-query", { // Update the URL to match your server
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ searchText: searchInput }),
  })
    .then((response) => response.text())
    .then((data) => {
      console.log(data); // Response from the server
    })
    .catch((error) => {
      console.error("Error sending search request:", error);
    });
  };
  return (
      <header>
        <Container fluid>
          <Row>
            <Col>
            <Navbar bg="light" expand="lg" className='MainNavbar'>
            <Navbar.Brand href="#" className="logo">PicLingo</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" className='sidebar'/>
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                  <Nav className="me-auto">
                    

                    <Nav.Link href="#" className='right-side'>About Us</Nav.Link>
                    <Nav.Link href="#" className='right-side'>How it Works</Nav.Link>
                    <Nav.Link href="#" className='right-side'>Sign Out</Nav.Link>
                    <Button className="cont-button">Contact Us</Button>
                  </Nav>
                  
                </Navbar.Collapse>
           
            </Navbar>
            </Col>
          </Row>
          <Row>
              <Col lg={6} className='TagAlign'>
                <h1 className="MainTag1">
                  <span className="FramesHeader">
                    <span className="Frames">Frames</span>
                    <span className="Unveiled"> Unveiled,</span>
                  </span>
                </h1>
               
                <h1 className="MainTag2">
                  <span className="WordsHeader">
                    <span className="Words">Words</span>
                    <span className="Tailored"> Tailored</span>
                  </span>
                </h1>
                <h3 className='SubTag'>Your Pictures, Your Words, Any Language.</h3>
                <br></br>
                <FormControl className="input-box"
                  
                    type="text"
                    placeholder="Paste or Type the URL of the image"
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                  
                />
                <br></br>

        <form action="#">
            <select className='drop-down' name="languages" id="lang">
                <option disabled selected>Select a Language</option>
                        <option value="af">Afrikaans</option>
                        <option value="sq">Albanian</option>
                        <option value="am">Amharic</option>
                        <option value="ar">Arabic</option>
                        <option value="hy">Armenian</option>
                        <option value="az">Azerbaijani</option>
                        <option value="eu">Basque</option>
                        <option value="be">Belarusian</option>
                        <option value="bn">Bengali</option>
                        <option value="bs">Bosnian</option>
                        <option value="bg">Bulgarian</option>
                        <option value="ca">Catalan</option>
                        <option value="ceb">Cebuano</option>
                        <option value="ny">Chichewa</option>
                        <option value="zh-cn">Chinese (Simplified)</option>
                        <option value="zh-tw">Chinese (Traditional)</option>
                        <option value="co">Corsican</option>
                        <option value="hr">Croatian</option>
                        <option value="cs">Czech</option>
                        <option value="da">Danish</option>
                        <option value="nl">Dutch</option>
                        <option value="en">English</option>
                        <option value="eo">Esperanto</option>
                        <option value="et">Estonian</option>
                        <option value="tl">Filipino</option>
                        <option value="fi">Finnish</option>
                        <option value="fr">French</option>
                        <option value="fy">Frisian</option>
                        <option value="gl">Galician</option>
                        <option value="ka">Georgian</option>
                        <option value="de">German</option>
                        <option value="el">Greek</option>
                        <option value="gu">Gujarati</option>
                        <option value="ht">Haitian Creole</option>
                        <option value="ha">Hausa</option>
                        <option value="haw">Hawaiian</option>
                        <option value="iw">Hebrew</option>
                        <option value="he">Hebrew</option>
                        <option value="hi">Hindi</option>
                        <option value="hmn">Hmong</option>
                        <option value="hu">Hungarian</option>
                        <option value="is">Icelandic</option>
                        <option value="ig">Igbo</option>
                        <option value="id">Indonesian</option>
                        <option value="ga">Irish</option>
                        <option value="it">Italian</option>
                        <option value="ja">Japanese</option>
                        <option value="jw">Javanese</option>
                        <option value="kn">Kannada</option>
                        <option value="kk">Kazakh</option>
                        <option value="km">Khmer</option>
                        <option value="ko">Korean</option>
                        <option value="ku">Kurdish (Kurmanji)</option>
                        <option value="ky">Kyrgyz</option>
                        <option value="lo">Lao</option>
                        <option value="la">Latin</option>
                        <option value="lv">Latvian</option>
                        <option value="lt">Lithuanian</option>
                        <option value="lb">Luxembourgish</option>
                        <option value="mk">Macedonian</option>
                        <option value="mg">Malagasy</option>
                        <option value="ms">Malay</option>
                        <option value="ml">Malayalam</option>
                        <option value="mt">Maltese</option>
                        <option value="mi">Maori</option>
                        <option value="mr">Marathi</option>
                        <option value="mn">Mongolian</option>
                        <option value="my">Myanmar (Burmese)</option>
                        <option value="ne">Nepali</option>
                        <option value="no">Norwegian</option>
                        <option value="or">Odia</option>
                        <option value="ps">Pashto</option>
                        <option value="fa">Persian</option>
                        <option value="pl">Polish</option>
                        <option value="pt">Portuguese</option>
                        <option value="pa">Punjabi</option>
                        <option value="ro">Romanian</option>
                        <option value="ru">Russian</option>
                        <option value="sm">Samoan</option>
                        <option value="gd">Scots Gaelic</option>
                        <option value="sr">Serbian</option>
                        <option value="st">Sesotho</option>
                        <option value="sn">Shona</option>
                        <option value="sd">Sindhi</option>
                        <option value="si">Sinhala</option>
                        <option value="sk">Slovak</option>
                        <option value="sl">Slovenian</option>
                        <option value="so">Somali</option>
                        <option value="es">Spanish</option>
                        <option value="su">Sundanese</option>
                        <option value="sw">Swahili</option>
                        <option value="sv">Swedish</option>
                        <option value="tg">Tajik</option>
                        <option value="ta">Tamil</option>
                        <option value="te">Telugu</option>
                        <option value="th">Thai</option>
                        <option value="tr">Turkish</option>
                        <option value="uk">Ukrainian</option>
                        <option value="ur">Urdu</option>
                        <option value="ug">Uyghur</option>
                        <option value="uz">Uzbek</option>
                        <option value="vi">Vietnamese</option>
                        <option value="cy">Welsh</option>
                        <option value="xh">Xhosa</option>
                        <option value="yi">Yiddish</option>
                        <option value="yo">Yoruba</option>
                        <option value="zu">Zulu</option>
      </select>
        </form>
        <Button className="gen-button" onClick={executePythonScript}>Start Generating Captions!</Button>
              </Col>
            <Col lg={6} className="ImagesContainer">
              <div className="background">
                {/* <img src="src/assets/LI_1.avif" alt="Image 1" className="image image1" /> */}
              </div>
            </Col>
          </Row>
        </Container>
      </header>
    );
};

export default Header